package com.code.api.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.code.api.entity.Book;
import com.code.api.repository.BookRepository;

@Service

public class BookService {
	@Autowired
	private
	BookRepository bookRepository;

	private final List<Book> books = List.of(
	        new Book(1,"Merchant of Venice", "William Shakespeare", 9630.00, "123456789"),
	        new Book(2,"Malgudi day", "R K Narayan",3650.23, "1523895630")
	    );
    public List<Book> getAllBooks() {
        // Logic to fetch all books
        return List.of(
            new Book(1,"Train to pakistan", "Khushwant singh", 6239.23, "ISBN1256356"),
            new Book(2,"Godan", "Munshi premchand", 9555.00, "ISBN975552542")
        );
    }
    public List<Book> getBooks()
    {
    	return getBookRepository().findAll();
    }
    public Book getBookId(int id)
    {
    	return getBookRepository().findById(id).get();
    }
    public Book getBookById(int id) {
        return books.stream()
            .filter(book -> book.getId()==id)
            .findFirst()
            .orElseThrow(() -> new RuntimeException("Book not found"));
    }

    public List<Book> filterBooks(String title, String author) {
        return books.stream()
            .filter(book -> (title == null || book.getTitle().equalsIgnoreCase(title)) &&
                            (author == null || book.getAuthor().equalsIgnoreCase(author)))
            .collect(Collectors.toList());
    }
    public List<Book> filterBooks1(String title, String author) {
    	List<Book> book1s= getBookRepository().findAll();
        return book1s.stream()
            .filter(book -> (title == null || book.getTitle().equalsIgnoreCase(title)) &&
                            (author == null || book.getAuthor().equalsIgnoreCase(author)))
            .collect(Collectors.toList());
    }
    public Book addBook(Book book)
    {
    	return getBookRepository().save(book);
    }
    public Book updateBook(int bookid,Book book)
    {
    	Book oldbook= getBookRepository().findById(bookid).get();
    	if(oldbook==null)
    	{
    		return null;
    	}
    	oldbook.setAuthor(book.getAuthor());
    	oldbook.setIsbn(book.getIsbn());
    	oldbook.setPrice(book.getPrice());
    	oldbook.setTitle(book.getTitle());
    	return getBookRepository().save(oldbook);
    }
    public String deleteBook(int id)
    {
    	Book book= getBookRepository().findById(id).get();
    	if(book==null)
    	{
    		return "Book Id"+id+" not found";
    	}
    	getBookRepository().delete(book);
    	return "Book Id"+id+" is deleted successfully";
    }
	public BookRepository getBookRepository() {
		return bookRepository;
	}
	public void setBookRepository(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}
}

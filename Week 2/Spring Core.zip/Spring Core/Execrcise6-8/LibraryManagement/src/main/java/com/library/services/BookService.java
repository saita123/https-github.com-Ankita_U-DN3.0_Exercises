package com.library.services;

import org.springframework.stereotype.Service;

@Service
public class BookService {

}

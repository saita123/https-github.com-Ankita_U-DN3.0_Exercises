package com.library.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagement9Application {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagement9Application.class, args);
	}

}

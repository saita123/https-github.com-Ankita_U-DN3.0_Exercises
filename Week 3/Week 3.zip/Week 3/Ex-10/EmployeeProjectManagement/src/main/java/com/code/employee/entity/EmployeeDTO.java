package com.code.employee.entity;


	import lombok.AllArgsConstructor;
	import lombok.Getter;

	@Getter
	@AllArgsConstructor
	public class EmployeeDTO {

	    private String name;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		private String email;
	    private double salary;
	    private int deptid;
		public Object getSalary() {
			return null;
		}
		public String getDeptid() {
			return null;
		}
		public Object getEmail() {
			return null;
		}
	}


